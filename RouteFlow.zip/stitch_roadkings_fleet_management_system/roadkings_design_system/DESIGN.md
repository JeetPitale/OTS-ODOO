---
name: RoadKings Design System
colors:
  surface: '#f8f9fa'
  surface-dim: '#d9dadb'
  surface-bright: '#f8f9fa'
  surface-container-lowest: '#ffffff'
  surface-container-low: '#f3f4f5'
  surface-container: '#edeeef'
  surface-container-high: '#e7e8e9'
  surface-container-highest: '#e1e3e4'
  on-surface: '#191c1d'
  on-surface-variant: '#5a4137'
  inverse-surface: '#2e3132'
  inverse-on-surface: '#f0f1f2'
  outline: '#8e7165'
  outline-variant: '#e2bfb2'
  surface-tint: '#a43e00'
  primary: '#a43e00'
  on-primary: '#ffffff'
  primary-container: '#ff6b1a'
  on-primary-container: '#591e00'
  inverse-primary: '#ffb596'
  secondary: '#565e74'
  on-secondary: '#ffffff'
  secondary-container: '#dae2fd'
  on-secondary-container: '#5c647a'
  tertiary: '#006493'
  on-tertiary: '#ffffff'
  tertiary-container: '#00a2eb'
  on-tertiary-container: '#003550'
  error: '#ba1a1a'
  on-error: '#ffffff'
  error-container: '#ffdad6'
  on-error-container: '#93000a'
  primary-fixed: '#ffdbcd'
  primary-fixed-dim: '#ffb596'
  on-primary-fixed: '#360f00'
  on-primary-fixed-variant: '#7d2d00'
  secondary-fixed: '#dae2fd'
  secondary-fixed-dim: '#bec6e0'
  on-secondary-fixed: '#131b2e'
  on-secondary-fixed-variant: '#3f465c'
  tertiary-fixed: '#cae6ff'
  tertiary-fixed-dim: '#8dcdff'
  on-tertiary-fixed: '#001e30'
  on-tertiary-fixed-variant: '#004b70'
  background: '#f8f9fa'
  on-background: '#191c1d'
  surface-variant: '#e1e3e4'
typography:
  headline-xl:
    fontFamily: Inter
    fontSize: 36px
    fontWeight: '700'
    lineHeight: 44px
    letterSpacing: -0.02em
  headline-lg:
    fontFamily: Inter
    fontSize: 28px
    fontWeight: '600'
    lineHeight: 36px
    letterSpacing: -0.01em
  headline-lg-mobile:
    fontFamily: Inter
    fontSize: 24px
    fontWeight: '600'
    lineHeight: 32px
  headline-md:
    fontFamily: Inter
    fontSize: 20px
    fontWeight: '600'
    lineHeight: 28px
  body-lg:
    fontFamily: Inter
    fontSize: 16px
    fontWeight: '400'
    lineHeight: 24px
  body-md:
    fontFamily: Inter
    fontSize: 14px
    fontWeight: '400'
    lineHeight: 20px
  label-md:
    fontFamily: Inter
    fontSize: 14px
    fontWeight: '600'
    lineHeight: 20px
  label-sm:
    fontFamily: Inter
    fontSize: 12px
    fontWeight: '500'
    lineHeight: 16px
rounded:
  sm: 0.25rem
  DEFAULT: 0.5rem
  md: 0.75rem
  lg: 1rem
  xl: 1.5rem
  full: 9999px
spacing:
  base: 8px
  container-margin: 24px
  gutter: 16px
  section-padding: 32px
  card-padding: 20px
---

## Brand & Style
The design system is built for a high-efficiency fleet operations environment. The brand personality is professional and dependable, moving away from the cluttered aesthetics of traditional logistics software toward a clean, modern, and breathable interface.

The visual style follows a **Modern Corporate** approach with a strong emphasis on **Minimalism**. By utilizing generous whitespace and a restricted color palette, the UI reduces cognitive load for operators managing complex real-time data. High-quality typography and soft geometry create a sense of calm authority and technological sophistication.

## Colors
The palette is dominated by high-contrast functional colors. The primary orange is used sparingly for action-oriented elements and critical brand touchpoints to maintain its urgency and significance. 

The background remains pure white to maximize the effect of whitespace, while surfaces use a very light gray to differentiate content containers from the canvas. Status indicators utilize a distinct semantic palette to ensure immediate recognition of vehicle and trip states without visual ambiguity.

## Typography
This design system utilizes **Inter** across all levels to maintain a systematic and utilitarian feel. The hierarchy relies on substantial weight differences between headings and body text to create clear information architecture. 

Headlines use a tighter letter-spacing for a modern, "locked-in" appearance, while body text uses standard spacing to prioritize legibility in data-heavy views. Label styles are frequently used for metadata and status badges, often paired with slightly increased font weights.

## Layout & Spacing
The layout follows a **Fixed Grid** model on desktop to ensure complex data visualizations remain consistent, transitioning to a fluid model on mobile devices. 

A 12-column grid is standard for dashboard views, allowing for flexible arrangements of fleet cards and telemetry widgets. Spacing is governed by an 8px base unit, with a preference for generous "Section Padding" (32px) to prevent the UI from feeling cramped. Elements should be grouped logically using "Gutter" (16px) spacing, creating a clear distinction between separate functional modules.

## Elevation & Depth
Depth is created through **Tonal Layers** and **Ambient Shadows**. The base canvas is white, while secondary functional areas (like maps or sidebars) may sit on the very light gray surface.

Interactive components like cards use a soft, diffused shadow (low opacity, large blur) to appear "lifted" from the surface. This creates a tactile quality that invites interaction without the harshness of high-contrast borders. Avoid heavy drop shadows; instead, use 2-4px Y-offsets with a 10-15% opacity neutral tint to suggest subtle elevation.

## Shapes
The shape language is defined by **large, friendly radii**. This soften the professional tone, making the platform feel approachable and modern rather than industrial or rigid. 

All primary containers, including cards and input fields, follow a 0.5rem base radius. Larger elements like hero sections or persistent side panels should utilize the `rounded-xl` (1.5rem) token to emphasize the soft-modern aesthetic. Buttons should consistently use the `rounded-lg` (1rem) setting to feel comfortable for touch and cursor interaction.

## Components

### Buttons
- **Primary:** Solid Orange (#FF6B1A) with White text. Bold, high-visibility.
- **Secondary:** Outline style using a Medium Gray border and Deep Charcoal text. High contrast but lower visual priority.
- **Icon Buttons:** Use thin Lucide-style icons with 1.5px stroke width.

### Sidebar
- **Background:** Solid White with a subtle right-hand border (#E5E7EB).
- **Active State:** A vertical orange pill-indicator on the left edge paired with a light orange (5% opacity) background tint for the active row.

### Cards
- **Style:** White background, 1rem corner radius, and subtle ambient shadow.
- **Padding:** 20px internally to ensure content has breathing room.

### Status Badges
- **Visuals:** Small, rounded-pill shapes with a light-tint background and dark-tint text of the same hue (e.g., On Trip uses a light blue background with dark blue text).
- **Icons:** Pair with a small 8px dot of the solid status color for quick scanning.

### Input Fields
- **Style:** Light gray (#F9FAFB) background with a subtle border that turns Orange on focus. 
- **Typography:** Labels should be `label-sm` in Deep Charcoal, positioned above the field.

### List Items
- **Style:** Separated by thin, light-gray dividers. Use a 4px hover state transition to the surface color (#F9FAFB) to indicate interactivity.